declare function isObject(x: unknown): x is object;

export = isObject;
